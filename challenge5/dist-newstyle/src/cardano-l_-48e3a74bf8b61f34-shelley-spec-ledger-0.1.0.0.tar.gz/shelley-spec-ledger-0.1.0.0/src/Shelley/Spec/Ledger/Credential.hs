module Shelley.Spec.Ledger.Credential
  {-# DEPRECATED "Use 'import Cardano.Ledger.Credential' instead." #-}
  (module X)
where

import Cardano.Ledger.Credential as X
